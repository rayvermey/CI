update-rc.d jottad defaults
